<?php
session_start();
include "navbar.php"; 
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}
?>

<h2>Welcome <?php echo $_SESSION["user_name"]; ?></h2>

<div id="area" style="width:400px;height:300px;border:2px solid #000;position:relative;overflow:hidden;">
    <div id="chair" style="font-size:40px;position:absolute;top:0;left:0;transition:0.2s;">
        ♿
    </div>
</div>

<br>

<button onclick="move('up')">Up</button>
<button onclick="move('down')">Down</button>
<button onclick="move('left')">Left</button>
<button onclick="move('right')">Right</button>
<a href="index.php" style="
    position: absolute;
    top: 10px;
    left: 10px;
    background: #f44336;
    color: white;
    padding: 8px 12px;
    text-decoration: none;
    border-radius: 6px;
    font-size: 14px;
">
    ⬅ Exit
</a>
<style>
body {
    font-family: Arial;
    background: #f5f7fb;
    text-align: center;
    padding-top: 60px;
}


h2 {
    color: #333;
}

#area {
    margin: 20px auto;
    width: 400px;
    height: 300px;
    border: 2px solid #333;
    background: white;
    position: relative;
    border-radius: 10px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.1);
}

button {
    padding: 10px 15px;
    margin: 5px;
    border: none;
    background: #4CAF50;
    color: white;
    border-radius: 6px;
    cursor: pointer;
}

button:hover {
    background: #45a049;
}

#chair {
    font-size: 40px;
    position: absolute;
    transition: 0.2s;
}

</style>

<script>

let chair = document.getElementById("chair");

let topPos = 0;
let leftPos = 0;

let areaWidth = 400;
let areaHeight = 300;

let chairSize = 40;

function move(direction) {

    if (direction == "up") topPos -= 10;
    if (direction == "down") topPos += 10;
    if (direction == "left") leftPos -= 10;
    if (direction == "right") leftPos += 10;

  
    if (topPos < 0) topPos = 0;
    if (topPos > areaHeight - chairSize) topPos = areaHeight - chairSize;

    if (leftPos < 0) leftPos = 0;
    if (leftPos > areaWidth - chairSize) leftPos = areaWidth - chairSize;

    chair.style.top = topPos + "px";
    chair.style.left = leftPos + "px";

   
    fetch("save_move.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: new URLSearchParams({
            direction: direction
        })
    });
}
</script>
