<?php
session_start();
include "connection.php";

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

$stmt = $conn->prepare("SELECT direction, time FROM movements WHERE user_id=? ORDER BY id DESC");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<h2>Your Movement History</h2>

<table border="1" cellpadding="10">
    <tr>
        <th>Direction</th>
        <th>Time</th>
    </tr>

    <?php while ($row = $result->fetch_assoc()) { ?>
        <tr>
            <td><?php echo $row["direction"]; ?></td>
            <td><?php echo $row["time"]; ?></td>
        </tr>
    <?php } ?>
</table>

<br>

<a href="demo.php">Go Back to Demo</a>
<style>
body {
    font-family: Arial;
    background: #f5f7fb;
    margin: 0;
    text-align: center; 
    padding-top: 60px;
}


h2 {
    margin-top: 80px;
    color: #333;
}

table {
    margin: 30px auto;
    border-collapse: collapse;
    width: 70%;
    background: white;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    border-radius: 10px;
    overflow: hidden;
}

th {
    background: #4CAF50;
    color: white;
    padding: 12px;
}

td {
    padding: 12px;
    border-bottom: 1px solid #eee;
}

tr:hover {
    background: #f1f1f1;
}

a {
    display: inline-block;
    margin-top: 20px;
    text-decoration: none;
    background: #2196F3;
    color: white;
    padding: 10px 15px;
    border-radius: 8px;
}

a:hover {
    background: #1976D2;
}
</style>