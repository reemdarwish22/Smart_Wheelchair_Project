<?php session_start(); 
 include "navbar.php"; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Smart Wheelchair Project</title>


<div class="navbar">

    <div class="logo"> Smart Wheelchair</div>

    <div>
        <a href="index.php">Home</a>

        <?php if (!isset($_SESSION["user_id"])) { ?>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        <?php } else { ?>
            <a href="demo.php">Demo</a>
            <a href="history.php">History</a>
            <a href="logout.php">Logout</a>
        <?php } ?>
    </div>

</div>
       <style> body {
            font-family: Arial;
            background: #f5f7fb;
            margin: 0;
            text-align: center;
            padding-top: 60px;

        }

        .container {
            padding: 60px;
        }

        h1 {
            color: #222;
        }

        p {
            color: #555;
            max-width: 600px;
            margin: auto;
            line-height: 1.6;
        }

        .btn {
            display: inline-block;
            margin: 10px;
            padding: 12px 20px;
            background: #4CAF50;
            color: white;
            text-decoration: none;
            border-radius: 8px;
        }

        .btn:hover {
            background: #45a049;
        }

        .box {
            margin-top: 30px;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>Smart Wheelchair System</h1>

    <p>
        This project is a simulation of a smart wheelchair system.
        Users can register, login, and control a virtual wheelchair movement.
        All movements are stored in a database in real-time.
    </p>

    <div class="box">

        <?php if (!isset($_SESSION["user_id"])) { ?>

            <a class="btn" href="login.php">Login</a>
            <a class="btn" href="register.php">Register</a>

        <?php } else { ?>

            <a class="btn" href="demo.php">Go to Demo ♿</a>
            <a class="btn" href="history.php">View History</a>

        <?php } ?>

    </div>

</div>


</body>
</html>