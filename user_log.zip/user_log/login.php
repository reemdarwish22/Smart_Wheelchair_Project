<?php
session_start();
include "connection.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST["email"];
    $password = $_POST["password"];

    $stmt = $conn->prepare("SELECT id, name, password FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows == 1) {

        $user = $result->fetch_assoc();

        if (password_verify($password, $user["password"])) {

            $_SESSION["user_id"] = $user["id"];
            $_SESSION["user_name"] = $user["name"];

            header("Location: index.php");
            exit();

        } else {
            $error = "Wrong password ❌";
        }

    } else {
        $error = "User not found ❌";
    }
}
?>

<div class="form-box">
    <h2>Login</h2>

    <?php if ($error) echo "<p style='color:red'>$error</p>"; ?>

    <form method="POST">
        <input name="email" placeholder="Email" required>
        <input name="password" type="password" placeholder="Password" required>
        <button>Login</button>
    </form>

    <div class="link">
        Don't have an account? <a href="register.php">Register</a>
    </div>
</div>
<style>
body {
    font-family: Arial;
    background: #f5f7fb;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.form-box {
    background: white;
    padding: 30px;
    width: 320px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    text-align: center;
}

.form-box h2 {
    margin-bottom: 20px;
    color: #333;
}

input {
    width: 100%;
    padding: 10px;
    margin: 8px 0;
    border: 1px solid #ccc;
    border-radius: 8px;
    outline: none;
}

input:focus {
    border-color: #4CAF50;
}

button {
    width: 100%;
    padding: 10px;
    margin-top: 10px;
    background: #4CAF50;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background: #45a049;
}

.link {
    margin-top: 10px;
    display: block;
    font-size: 14px;
    color: #555;
}

.link a {
    color: #4CAF50;
    text-decoration: none;
}
</style>