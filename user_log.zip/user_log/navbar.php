
<div class="navbar">
    <div class="logo">Smart Wheelchair</div>

    <!-- زر الهامبرجر -->
    <div class="menu-toggle" onclick="toggleMenu()">
        ☰
    </div>

    <div class="nav-links" id="navLinks">
        <a href="#">Home</a>
        <a href="#">Demo</a>
        <a href="#">History</a>
        <a href="#">Login</a>
    </div>
</div>
<style>
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: Arial, sans-serif;
}

.navbar {
    background: #1f1f1f;
    padding: 12px 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;

    position: fixed;
    top: 0;
    left: 0;
    width: 100%;

    z-index: 1000;
    box-shadow: 0 4px 12px rgba(0,0,0,0.2);
}

.logo {
    color: #4CAF50;
    font-weight: bold;
    font-size: 20px;
}

.nav-links {
    display: flex;
    gap: 20px;
}

.nav-links a {
    color: white;
    text-decoration: none;
    font-size: 15px;
    transition: 0.3s;
}

.nav-links a:hover {
    color: #4CAF50;
}

/* زر الهامبرجر */
.menu-toggle {
    display: none;
    font-size: 26px;
    color: white;
    cursor: pointer;
}

/* ===== Mobile ===== */
@media (max-width: 768px) {

    .menu-toggle {
        display: block;
    }

    .nav-links {
        position: absolute;
        top: 60px;
        right: 0;
        background: #1f1f1f;
        width: 200px;

        flex-direction: column;
        gap: 15px;

        padding: 15px;

        display: none; /* مخفية افتراضي */
        box-shadow: -2px 4px 12px rgba(0,0,0,0.3);
    }

    .nav-links.show {
        display: flex;
    }
}</style>
<script>
function toggleMenu() {
    const nav = document.getElementById("navLinks");
    nav.classList.toggle("show");
}
</script>

