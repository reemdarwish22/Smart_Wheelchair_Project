<?php
include "connection.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $password);

    if ($stmt->execute()) {
        header("Location: login.php");
        exit();
    } else {
        echo "Error ❌";
    }
}
?>

<div class="form-box">
    <h2>Register</h2>

    <form method="POST">
        <input name="name" placeholder="Name" required>
        <input name="email" placeholder="Email" required>
        <input name="password" type="password" placeholder="Password" required>
        <button>Register</button>
    </form>

    <div class="link">
        Already have account? <a href="login.php">Login</a>
    </div>
</div>
<style>
body {
    font-family: Arial;
    background: #f5f7fb;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.form-box {
    background: white;
    padding: 30px;
    width: 320px;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    text-align: center;
}

.form-box h2 {
    margin-bottom: 20px;
    color: #333;
}

input {
    width: 100%;
    padding: 10px;
    margin: 8px 0;
    border: 1px solid #ccc;
    border-radius: 8px;
    outline: none;
}

input:focus {
    border-color: #4CAF50;
}

button {
    width: 100%;
    padding: 10px;
    margin-top: 10px;
    background: #4CAF50;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background: #45a049;
}

.link {
    margin-top: 10px;
    display: block;
    font-size: 14px;
    color: #555;
}

.link a {
    color: #4CAF50;
    text-decoration: none;
}
</style>