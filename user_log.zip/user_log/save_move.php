<?php
session_start();
include "connection.php";

if (!isset($_SESSION["user_id"])) {
    exit();
}

$user_id = $_SESSION["user_id"];
$direction = $_POST["direction"];

$stmt = $conn->prepare("INSERT INTO movements (user_id, direction) VALUES (?, ?)");
$stmt->bind_param("is", $user_id, $direction);
$stmt->execute();
?>